USE  [Midterm Project]
GO

SELECT * 
FROM [dbo].[HR_Analytics]

---we have 10 Duplicates
select EmpID, EmployeeNumber, count(*)
FROM [Midterm Project].[dbo].[HR_Analytics]
Group by EmpID, EmployeeNumber having count(*)>1;

----delete duplicates
with CTE as
(
select *,ROW_NUMBER() over(partition by EmpID,EmployeeNumber Order by EmpID,EmployeeNumber) Rownumber from [dbo].[HR_Analytics]
)
Delete  from CTE where rownumber>1


---
SELECT *  
FROM [dbo].[EducationLevel]

SELECT * 
FROM [dbo].[RatingLevel]

SELECT * 
FROM [dbo].[SatisfiedLevel]

---1) What is the employee headcount? Num of people working in the company

Select count(EmployeeNumber) as  NumofEmp
from [dbo].[HR_Analytics]

---2) What is the breakdown of the headcount by the following?  Gender,Department,Job Role/title,Marital status 

---headcount by Gender 
Select Gender, count(EmployeeNumber) as  NumofEmp
from [dbo].[HR_Analytics]
group by Gender
order by NumofEmp

---headcount by Department
Select Department, count(EmployeeNumber) as  NumofEmp
from [dbo].[HR_Analytics]
group by Department
order by NumofEmp

---headcount by JobRole
Select JobRole, count(EmployeeNumber) as  NumofEmp
from [dbo].[HR_Analytics]
group by JobRole
order by NumofEmp

---headcount by Marital status
Select Maritalstatus, count(EmployeeNumber) as  NumofEmp
from [dbo].[HR_Analytics]
group by Maritalstatus
order by NumofEmp

---3) What is the total monthly salary the company paid?
SELECT SUM(MonthlyIncome) as TotalMonthlySalary
from [dbo].[HR_Analytics]


---4) What is the employee turnover rate?
---turnover rate %
select  
cast(sum(case when attrition = 'yes' then 1 else 0 end)as decimal(7,2))
/
count(*) * 100 as EmployeeTurnover
from [dbo].[HR_Analytics]


---5) What is the ratio of attrition by department? 

----% ratio of attr by Dep
select department, COUNT(attrition) * 100 / sum(count(attrition)) over() as PercentageAttr
from [dbo].[HR_Analytics]
Where attrition = 'yes'
group by department
order by PercentageAttr 


---6) What is the ratio of attrition by Job role?
---% ratio of attrition by Job role
select JobRole, COUNT(attrition) * 100.0 / sum(count(attrition)) over() as PercentageAttr
from [dbo].[HR_Analytics]
Where attrition = 'yes'
group by JobRole
order by PercentageAttr 

---7) What percentage of employees are in a certain age bracket? 
----%percentage of employees are in a certain age bracket? 
select AgeGroup, count(EmployeeNumber) * 100 / sum(count(EmployeeNumber)) over() as EmpPer
from [dbo].[HR_Analytics]
group by AgeGroup
order by EmpPer


---8) Is there any correlation between age group and monthly income? YES
SELECT AgeGroup, Round (AVG(MonthlyIncome),0) AS AvgMonthlyIncome
FROM [dbo].[HR_Analytics]
GROUP BY AgeGroup
ORDER BY AVG(MonthlyIncome) 

---9) What percentage of employees are in a certain performance rating? 
select PerformanceRating, count(EmployeeNumber) * 100.0 / sum(count(EmployeeNumber)) over() as EmpPer
from [dbo].[HR_Analytics]
group by PerformanceRating
order by EmpPer 


---10) What is the Job satisfaction score of the company?

SELECT round(Avg(JobSatisfaction),1) avgSatisfaction
FROM [dbo].[HR_Analytics]

---11) What is the Job satisfaction score by department? 
SELECT department, round(avg(JobSatisfaction),1) AS avgJobSat
FROM [dbo].[HR_Analytics]
GROUP BY department
ORDER BY avgJobSat

---12) What is the Job satisfaction score by Job role?
SELECT JobRole, round(avg(JobSatisfaction),2) AS avgJobSat
FROM [dbo].[HR_Analytics]
GROUP BY JobRole
ORDER BY avgJobSat

---13) Is there any correlation between job satisfaction level and employee retention? YES

--create view [dbo].[VW_jobsatisfactionanalysi]
--as
--select  s.SatisfactionID, Attrition, YearsAtCompany, SatisfactionLevel, EmployeeNumber, RelationshipSatisfaction, TrainingTimesLastYear
--from [dbo].[HR_Analytics] a inner join [dbo].[SatisfiedLevel] s on a.JobSatisfaction=s.SatisfactionID
---answer
select SatisfactionLevel, COUNT(attrition)  * 100.0 / sum(count(EmployeeNumber)) over()  as PercentageAttr
from VW_jobsatisfactionanalysis
Where attrition = 'yes' 
group by SatisfactionLevel
order by PercentageAttr



---14) What are the total training hours per department? 
select department, sum(TrainingTimesLastYear) as TotalTrainingHR
from [dbo].[HR_Analytics]
group by department
order by TotalTrainingHR

---15) Is there any correlation between job satisfaction level and Training hours? NO
select SatisfactionLevel, round(sum(TrainingTimesLastYear),3) as totalTrainingTime
from [dbo].[VW_jobsatisfactionanalysi]
group by SatisfactionLevel
order by totalTrainingTime 